<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <aside class="sidebar">
        <nav>
        <ul>
            <li><a href="conectar.php">Testa Conexão</a></li>
            <li><a href="tabela.php">Criar tabela</a></li>
            <li><a href="inserir.php">Inserir Dados</a></li>
            <li><a href="recuperar.php">Exibir Informações</a></li>
        </ul>
    </nav>
</div>
  

</body>
</html>